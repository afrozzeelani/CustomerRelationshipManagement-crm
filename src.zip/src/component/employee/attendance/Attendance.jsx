import React from 'react'

const Attendance = () => {
  return (
    <div>
      Afroz Zeelani
    </div>
  )
}

export default Attendance
