// Attendance.jsx
import React, { useState, useEffect } from "react";

const Attendance = () => {
  const [attendance, setAttendance] = useState([]);
  const [isLogged, setIsLogged] = useState(false);

  const handleLogin = async () => {
    const now = new Date();
    try {
      const response = await fetch('http://localhost:4000/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: 1,
          loginTime: now.toISOString(),
        }),
      });
      if (response.ok) {
        setIsLogged(true);
        await fetchAttendanceData();
      } else {
        console.error('Failed to log in');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  // const handleLogout = async () => {
  //   const now = new Date();
  //   try {
  //     const response = await fetch('http://localhost:4000/logout', {
  //       method: 'POST',
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //       body: JSON.stringify({
  //         userId: 1,
  //         logoutTime: now.toISOString(),
  //       }),
  //     });
  //     if (response.ok) {
  //       setIsLogged(false);
  //       await fetchAttendanceData();
  //     } else {
  //       console.error('Failed to log out');
  //     }
  //   } catch (error) {
  //     console.error('Error:', error);
  //   }
  // };

   const handleLogout = async () => {
  const now = new Date();
  try {
    const response = await fetch('http://localhost:4000/logout', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        employeeId: 1,  // Change this to match the server's expected format
        logoutTime: now.toISOString(),
      }),
    });
    if (response.ok) {
      setIsLogged(false);
      await fetchAttendanceData();
    } else {
      console.error('Failed to log out');
    }
  } catch (error) {
    console.error('Error:', error);
  }
};


  const fetchAttendanceData = async () => {
    try {
      const response = await fetch('http://localhost:4000/attendance');
      if (response.ok) {
        const data = await response.json();
        setAttendance(data);
      } else {
        console.error('Failed to fetch attendance data');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  };

  useEffect(() => {
    fetchAttendanceData();
  }, []); // This effect runs once when the component mounts

  const calculateAttendanceStatus = () => {
    const loginTimes = attendance[0]?.months[0]?.dates[0]?.loginTime || [];

    if (loginTimes.length > 0) {
      const lastLoginTime = new Date(loginTimes[loginTimes.length - 1]);
      const currentTime = new Date();
      const timeDifference = (currentTime - lastLoginTime) / (1000 * 60);

      if (timeDifference <= 15) {
        return "On Time";
      } else if (timeDifference <= 30) {
        return "Slightly Late";
      } else if (timeDifference <= 60) {
        return "Late";
      } else {
        return "Very Late";
      }
    } else {
      return "Absent";
    }
  };

  return (
    <div>
      <h4 className="mb-5">Attendance System</h4>
      <div className="d-flex gap-5">
        <button
          className="btn btn-success"
          onClick={handleLogin}
          disabled={isLogged}
        >
          Login
        </button>
        <button
          className="btn btn-danger"
          onClick={handleLogout}
          disabled={!isLogged}
        >
          Logout
        </button>
      </div>
      {attendance.map((year) => (
        <div key={year.id}>
          <h2>Year: {year.year}</h2>
          {year.months.map((month) => (
            <div key={month.month}>
              <h3>Month: {month.month}</h3>
              {month.dates.map((date) => (
                <div key={date.id}>
                  <h4>Date: {date.date}</h4>
                  <p>
                    Login Times:{" "}
                    {date.loginTime.map((time) =>
                      new Date(time).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                        hour12: false,
                      })
                    )}
                  </p>
                  <p>
                    Logout Times:{" "}
                    {date.logoutTime.map((time) =>
                      new Date(time).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                        hour12: false,
                      })
                    )}
                  </p>
                  <p>Break Times: {date.breakTime.join(", ")}</p>
                  <p>Total Break Time: {date.TotalBreakTime.toFixed(2)} minutes</p>
                  <p>Status: {date.status} </p>
                </div>
              ))}
            </div>
          ))}
        </div>
      ))}
      <div>
        <h4>Attendance Status:</h4>
        <p>{calculateAttendanceStatus()}</p>
      </div>
    </div>
  );
};

export default Attendance;
