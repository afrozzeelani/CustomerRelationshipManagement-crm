import styles from './backdrop.module.scss';

export default function Backdrop() {
  return <div className={styles.backdrop}></div>;
}
