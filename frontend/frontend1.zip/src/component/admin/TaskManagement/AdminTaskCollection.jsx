// import React from 'react'

// export default function AdminTaskCollection() {
//   return (
//     <div>AdminTaskCollection</div>
//   )
// }

import React, { useState } from "react";
import { Button } from "react-bootstrap";

const AdminTaskCollection = ({ task, onUpdateStatus }) => {
  const [status, setStatus] = useState(task.status);
  const [onbuttonClicked, setButtonClicked] = useState(false);

  const handleStatusChange = (newStatus) => {
    setStatus(newStatus);
    onUpdateStatus(task.id, newStatus);
    setButtonClicked(true)
  };

  const renderStatusOverlay = () => {
    if (status === "Rejected") {
      return (
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            background: "rgba(255, 0, 0, 0.5)",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            pointerEvents: "none", // Allow clicks to pass through the overlay
          }}
        >
          <span style={{ color: "white", fontSize: "24px" }}>Rejected</span>
        </div>
      );
    }

    return null;
  };
  

  return (
    <div id="Lappu" className="container p-0 gap-2 d-flex flex-column">
    <details className="px-3 form-control py-2 mt-3 fs-4 ">
      <summary> # {task.name}</summary>
      <div style={{ boxShadow: '0 0 2px 3px rgba(199, 195, 195, 0.808)', position:'relative' }} className="row p-1 my-2 mx-0 bg-dark text-black rounded">
        <div>
          <p className="text-center"><span className="fs-5 text-danger">Project Description</span ><br />{task.description}</p>
          <div className="row bg-black pt-3 rounded mx-1 justify-content-between">
            <p style={{fontSize:'1rem'}} className="col-6 col-sm-6 col-md-2 text-center">Task Durations <br /> <span >{task.duration} days</span> </p>
            <p style={{fontSize:'1rem'}} className="col-6 col-sm-6 col-md-2 text-center">Manager's Email <br />   <span >{task.managerEmail}</span></p>
            <p style={{fontSize:'1rem'}} className="col-6 col-sm-6 col-md-2 text-center">Start Date <br /> <span >{task.startDate}</span></p>
            <p style={{fontSize:'1rem'}} className="col-6 col-sm-6 col-md-2 text-center">End Date <br /> <span >{task.endDate}</span></p>
            <p style={{fontSize:'1rem'}} onChange={()=>{renderStatusOverlay()}} id="StatusHandel" className="col-6 col-sm-6 col-md-2 text-center">Status<br />{status}</p>
          </div>
        </div>
        <div className="d-flex gap-2 justify-content-between p-2">
          <Button id="Pending" variant="primary" onClick={() => handleStatusChange("Pending")} disabled={onbuttonClicked}>
            Accept
          </Button>
          <Button id="Reject" variant="danger" onClick={() => handleStatusChange("Reject")} disabled={onbuttonClicked}>
            Reject
          </Button>
          <Button id="Completed" variant="success" onClick={() => handleStatusChange("Completed")}>
            Complete
          </Button>
        </div>
      </div>
    </details>
    </div>
  );
};

export default AdminTaskCollection;

