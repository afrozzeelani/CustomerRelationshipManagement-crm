
import React from 'react';
import Task from './TaskCollection';

const AdminTaskList = ({ tasks, onUpdateStatus }) => {
    
  return (
    <div>
      {tasks.map((task) => (
        <Task key={task.id} task={task} onUpdateStatus={onUpdateStatus} />
      ))}
    </div>
  );
};

export default AdminTaskList;
