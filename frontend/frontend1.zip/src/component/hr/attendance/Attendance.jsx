
import react,  { useEffect, useState } from "react";
const Attendance = () => {
const [empAttendence, setempAttendence] = useState([
    {
      year: new Date().getFullYear(),
      months: [
        {
          month: new Date().getMonth() + 1,
          dates: [
            {
              date: new Date().getDate(),
              loginTime: [],
              logoutTime: [],
              breakTime: [],
              TotalBreakTime: 0, // Initialize TotalBreakTime
            },
          ],
        },
      ],
    },
  ]);
  const [isLogged, setIsLogged] = useState(false); // To track login/logout state
  useEffect(() => {
    // Function to add a new year when the year changes
    const checkForYearChange = () => {
      const now = new Date();
      const currentYear = now.getFullYear();
      if (currentYear !== empAttendence[0].year) {
        setempAttendence([
          {
            year: currentYear,
            months: [
              {
                month: now.getMonth() + 1,
                dates: [
                  {
                    date: now.getDate(),
                    day: now.getDay(),
                    loginTime: [],
                    logoutTime: [],
                    breakTime: [],
                    TotalBreakTime: 0,
                  },
                ],
              },
            ],
          },
          ...empAttendence,
        ]);
      }
    };
    // Function to add a new month when the month changes
    const checkForMonthChange = () => {
      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth() + 1;
      if (
        currentYear === empAttendence[0].year &&
        currentMonth !== empAttendence[0].months[0].month
      ) {
        empAttendence[0].months.unshift({
          month: currentMonth,
          dates: [
            {
              date: now.getDate(),
              day: now.getDay(),
              loginTime: [],
              logoutTime: [],
              breakTime: [],
              TotalBreakTime: 0,
            },
          ],
        });
        setempAttendence([...empAttendence]);
      }
    };
    // Function to add a new date when the date changes
    const checkForDateChange = () => {
      const now = new Date();
      const currentYear = now.getFullYear();
      const currentMonth = now.getMonth() + 1;
      const currentDate = now.getDate();
      if (
        currentYear === empAttendence[0].year &&
        currentMonth === empAttendence[0].months[0].month &&
        currentDate !== empAttendence[0].months[0].dates[0].date
      ) {
        empAttendence[0].months[0].dates.unshift({
          date: currentDate,
          day: now.getDay(),
          loginTime: [],
          logoutTime: [],
          breakTime: [],
          TotalBreakTime: 0,
        });
        setempAttendence([...empAttendence]);
      }
    };
    // Check for changes and add new entries
    checkForYearChange();
    checkForMonthChange();
    checkForDateChange();
  }, [empAttendence]);
  const handleLogin = () => {
    const now = new Date();
    const loginTime = now;
    // Find the last logout time of the same date
    const lastLogoutTime = empAttendence[0].months[0].dates[0].logoutTime.slice(-1)[0];
    const lastLogoutDateTime = lastLogoutTime ? new Date(lastLogoutTime) : null;
    // Calculate the break time in milliseconds
    const breakTimeMs = lastLogoutDateTime ? now - lastLogoutDateTime : 0;
    // Convert the break time from milliseconds to minutes
    const breakTimeMinutes = (breakTimeMs / (1000 * 60)).toFixed(2);
    empAttendence[0].months[0].dates[0].loginTime.push(loginTime);
    empAttendence[0].months[0].dates[0].breakTime.push(Number(breakTimeMinutes));
    setIsLogged(true);
    setempAttendence([...empAttendence]);
  };
  const handleLogout = () => {
    const now = new Date();
    empAttendence[0].months[0].dates[0].logoutTime.push(now);
    setIsLogged(false);
    setempAttendence([...empAttendence]);
  };
  // Calculate and update TotalBreakTime
  useEffect(() => {
    const totalBreakTime = empAttendence[0].months[0].dates[0].breakTime.reduce(
      (acc, breakTime) => acc + breakTime,
      0
    );
    empAttendence[0].months[0].dates[0].TotalBreakTime = totalBreakTime;
    setempAttendence([...empAttendence]);
  }, []);
  const calculateAttendanceStatus = () => {
    const loginTime = empAttendence[0].months[0].dates[0].loginTime[0];
    // Check if login time exists and is not an empty string
    if (loginTime && loginTime !== "") {
      const loginHour = new Date(loginTime).getHours();
      const loginMinute = new Date(loginTime).getMinutes();
      // Check if login time is less than or equal to 9:45 am
      if (loginHour < 9 || (loginHour === 9 && loginMinute <= 45)) {
        return "Present";
      } else {
        return "Half Day";
      }
    } else {
      return "Absent";
    }
  };
  return (
    <div className="container d-flex flex-column justify-content-center  align-items-center">
      <h4 className="mb-5">CODETEST COPY</h4>
      <div className="d-flex gap-5">
        <button className="btn btn-success" onClick={handleLogin} disabled={isLogged}>
          Login
        </button>
        <button className="btn btn-danger" onClick={handleLogout} disabled={!isLogged}>
          Logout
        </button>
      </div>
      {empAttendence.map((year) => (
        <div key={year.year}>
          <h2>Year: {year.year}</h2>
          {year.months.map((month) => (
            <div key={month.month}>
              <h3>Month: {month.month}</h3>
              {month.dates.map((date) => (
                <div key={date.date}>
                  <h4>Date: {date.date}</h4>
                  <p>Login Times: {date.loginTime.map(time => time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })).join(", ")}</p>
                  <p>Logout Times: {date.logoutTime.map(time => time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })).join(", ")}</p>
                  <p>Break Times: {date.breakTime.join(", ")}</p>
                  <p>Total Break Time: {date.TotalBreakTime.toFixed(2)} minutes</p>
                </div>
              ))}
            </div>
          ))}
        </div>
      ))}
      <div>
        <h4>Attendance Status:</h4>
        <p>{calculateAttendanceStatus()}</p>
      </div>
    </div>
  );
};
export default Attendance;
